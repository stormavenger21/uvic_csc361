import struct
import io
import re
import sys
import socket
import ssl
import math
import statistics

from globalHeader import globalHeader
from packet import Packet

'''

this assignment uses code excerpts from packet_struct.py, which was provided in assignment 2

https://realpython.com/python-data-structures/#structstruct-serialized-c-structs
'''

ETHERNET_H_SZ=14
PACKET_H_SZ=16
GLOBAL_H_SZ=24
GLOBAL_P=[]
DECIMAL_PLACES=3




def main():
    
    try:
        fn=readAndCheck()
        splitPackets=openAndProcess(fn)
        if(len(splitPackets)!=0):
            linuxCall(splitPackets)
    except:
        print("error opening .pacp file ")
        sys.exit()




def readAndCheck():
    '''
    performs error checking on user input
    '''
    fileName=""
    try:
        fileName=sys.argv[1]
    except:
        sys.exit()
    if len(sys.argv) < 2:
        print("Error: invalid length")
        sys.exit()
    return fileName


def openAndProcess(fileName):
    '''
    Opens the provided file, reads data, and processes packets.

    param: fileName (str):          The name of the capfile.
    Returns: list                   A list of packets categorized as UDP or ICMP.
    '''
    count=0
    udp=[]
    tcp=[]
    icmp=[]
    ip=[]
    listOfPackets=[]

    f=open(fileName,"rb")
    pcapFile=f.read()
    f.close()

    globalHeaderBinary, restOfFile=readFile(pcapFile,GLOBAL_H_SZ)
    newGlobalHeader=globalHeader()
    newGlobalHeader.get_Global_H(globalHeaderBinary)
    endianess=newGlobalHeader.endian


    while restOfFile>bytes(0):
        restOfFile = process_packets(restOfFile, endianess, newGlobalHeader, udp, icmp, count)
 
    #print("udp_list: {}".format(udp))
    for p in udp:
        if p.fragmented:
            for i in udp:
                count2=0
                if(p.IP_header.Identification==i.IP_header.Identification):
                    if i.fragmented is False:
                        p.protocol.src_port=(i.protocol.src_port)
                        p.protocol.dst_port=(i.protocol.dst_port)
                        count2+=1
                #print(count2)
    listOfPackets.append(udp)
    listOfPackets.append(icmp)
    return listOfPackets


def process_packets(restOfFile, endianess, newGlobalHeader, udp, icmp, count):
    '''
    Processes a packet from the provided binary data and categorizes it as UDP or ICMP.

       param restOfFile (bytes):    The remaining binary data to process.
       param endianess (str):       The endianness of the data.
       param newGlobalHeader:       An instance of the global header.
       param udp (list):            A list to store UDP packets.
       param icmp (list):           A list to store ICMP packets.
       param count (int):           The count of processed packets.
       returns: bytes:              The updated binary data after processing a packet.
    '''
    packetObject1 = Packet()
    packet_header, restOfFile = readFile(restOfFile, PACKET_H_SZ)
    inclLen = packetObject1.getInclLen(packet_header, endianess, newGlobalHeader.microSec)
    nextData, restOfFile = readFile(restOfFile, inclLen)
    packetObject1.packetData(nextData)

    if packetObject1.protocol_type == "ICMP":
        icmp.append(packetObject1)
    elif packetObject1.protocol_type == "UDP":
        udp.append(packetObject1)
    count += 1

    return restOfFile


def getNextPacket(inPacketHeader,endianess,numPackets):
    '''
    read packets and update the remaining binary file

    param inPacketHeader:   the cap file
    param endianess:        little or big
    param numPackets:       a count of each packet
    returns:                <bytes> inPacketHeader: the remaining cap file
                            <packet_struct.packet> packetObj1: the processed packet extracted from cap file 
    '''
    pHeader,inPacketHeader=readFile(inPacketHeader,PACKET_H_SZ)
    obj1=Packet()
    dataSize=obj1.getInclLen(pHeader,endianess,numPackets)
    nextData,inPacketHeader=readFile(inPacketHeader,dataSize)
    obj1.packetData(nextData)
    GLOBAL_P.append(obj1)
    return inPacketHeader, obj1



def readFile(inFile, lengthToRead):
    '''
    read part of the input file

    param inFile:       the binary data
    param lengthToRead: length to stop the first packet at
    returns:            <bytes> startPacket: the first packet in a series of possibly many
                        <bytes> remainingPackets: all the rest of the packets               
    '''
    startPacket=inFile[0:lengthToRead]
    inFile=inFile[lengthToRead:]
    return startPacket,inFile


def numPackets(inArray):
    """
    total connections counter, init development
    """
    count=0
    for x in inArray:
        count+=1
    return count    


def getGlobalHeader(inHeader):
    '''
    create a global header object and populate with data

    param inHeader:     first 24 bytes of the cap file
    returns:            <packet_struct.globalHeader> 
                        the global header object
    ''' 
    globH_obj1=globalHeader()
    globH_obj1.get_Global_H(inHeader)
    return globH_obj1


def sort(a,b,var):
    '''
    build list to determine connection info
             
    '''
    top=a[0]
    result=a,b
    try:
        l1=top.getIPandTCPheader()
    except:
        print("error get TCP")
    inList = False
    for i,pack in enumerate(b):
        t1 = pack[0].getIPandTCPheader()
        if l1[0] in t1 and var==True:
            if l1[1] in t1 and var==True:
                inList=True
                pack.append(top)
                b[i]=pack
                result=a[1:], b
                return result
    if not inList:
        pack=[top]
        b.append(pack)
        return a[1:], b


def getNumResetsHelper1(inPacketsArr):
    for px in inPacketsArr:
        t1=px.getflags()
        count=0
        if (t1['RST']==1):
            count+=1
    return count


def getNumConnectionsHelper1(inPackets,next,outputArr):
    p1=inPackets[next]
    t1=p1.getflags()
    if (t1['ACK']==1) and (t1['SYN']==1):
        outputArr.append(p1) 
    return outputArr



def process_router_ips(destinationNode, sortedList, initDestinationIP, ultimateDestinationIP):
    """
    Processes sorted router IP information to categorize and differentiate intermediary and ultimate destination nodes

    Param:
    - destinationNode (str): IP address of the ultimate destination node.
    - sortedList (list): List containing sorted router IP information with Time To Live (TTL) values.
    - initDestinationIP (list): List to store intermediary destination node information.
    - ultimateDestinationIP (list): List to store ultimate destination node information.

    """
    for element in sortedList:
        ttl = element[0]
        i = element[1][1]
        routerIP = i.IP_header.src_ip
        if routerIP != destinationNode:
            payload = [ttl, routerIP, [element[1]]]
            itemExists = False
            for i, existing_payload in enumerate(initDestinationIP):
                if payload[0] == existing_payload[0] and payload[1] == existing_payload[1]:
                    existP = existing_payload[2]
                    existP.append(payload[2][0])
                    payloadNew = [existing_payload[0], existing_payload[1], existP]
                    initDestinationIP[i] = payloadNew
                    itemExists = True
                    break
            if not itemExists:
                initDestinationIP.append(payload)
        else:
            payload = [ttl, routerIP, [element[1]]]
            itemExists = False
            for i, existing_payload in enumerate(ultimateDestinationIP):
                if payload[1] == existing_payload[1]:
                    existP = existing_payload[2]
                    existP.append(payload[2][0])
                    payloadNew = [existing_payload[0], existing_payload[1], existP]
                    ultimateDestinationIP[i] = payloadNew
                    itemExists = True
                    break
            if not itemExists:
                ultimateDestinationIP.append(payload)


def linuxCall(inputPacketsArray):
    """
    Processes a series of input packets array to determine routing information and analyze network traces

    Param:
    - inputPacketsArray (list): An array containing input packets information

    Returns:
    - None

    This function extracts routing and network trace information from the inputPacketsArray variable. It identifies source and 
      destination nodes, matches UDP packets, sorts and processes packet information to produce intermediary 
      routing data. Then it generates and displays network trace results using the function 'process_linux_results'
    """
    initPacket = inputPacketsArray[0][0]
    sourceNode = initPacket.IP_header.src_ip
    destinationNode = initPacket.IP_header.dst_ip
    list1=[]
    for p1 in inputPacketsArray[0]:
        udpSourcePort = p1.protocol.sourcePort
        payload = []
        for i in inputPacketsArray[1]:
            icmp_container = i.protocol
            if "UDP" in icmp_container.encapsulatedProtocol:
                var_1 = icmp_container.encapsulatedProtocol["UDP"].sourcePort
                if var_1 == udpSourcePort:
                    payload = [p1, i]
                    break
            else:
                print("No source node")
                print(i)
                print("ICMP")
                print(icmp_container)

        if len(payload)>0:
            list1.append(payload)

    unsortedListofPairs = []
    for pair in list1:
        ttl = pair[0].IP_header.TTL
        unsortedListofPairs.append([ttl, pair])

    sortedList=sorted(unsortedListofPairs,key=lambda x: x[0])

    initDestinationIP = []  
    ultimateDestinationIP = []
    
    process_router_ips(destinationNode, sortedList, initDestinationIP, ultimateDestinationIP)
    process_linux_results(sourceNode, destinationNode, initDestinationIP, ultimateDestinationIP)
    return


def process_linux_results(sourceNode, destinationNode, initDestinationIP, ultimateDestinationIP):
    """
    Process and display network trace results from a Linux system

    Param:
    - sourceNode (str): IP address of the source node
    - destinationNode (str): IP address of the ultimate destination node
    - initDestinationIP (list): List containing tuples with distance to source and intermediate node IP addresses
    - ultimateDestinationIP (list): List containing tuples with intermediate node IP addresses for the ultimate destination

    Prints:
    - Displays information regarding the source node, destination node, intermediate nodes, protocol field values,
      number of fragments created, offset of the last fragment, average Round-Trip Time (RTT), and standard deviation
    """
    print("========================================================================")
    print("The IP address of the source node: ")
    print(sourceNode)
    print("")
    print("The IP address of ultimate destination node: ")
    print(destinationNode)
    print("")
    print("")
    print("The IP addresses of the intermediate destination nodes: ")
    for rNum, pairX in enumerate(initDestinationIP):
        print("\trouter {}: {}, distance to source: {}".format(rNum + 1, pairX[1], pairX[0]))
    print("\nThe values in the protocol field of IP headers:\n\t1: ICMP\n\t17: UDP\n")
    
    print("The number of fragments created from the original datagram is: 0")

    print("The offset of the last fragment is: 0\n")
    for pairX in initDestinationIP:
        routerIP = []
        standardDeviation = 0.0
        mean = 0.0
        for el1 in pairX[2]:
            rttResult = (el1[1].timestamp - el1[0].timestamp) * 1000
            routerIP.append(rttResult)
        if len(routerIP) > 1:
            mean = round(statistics.mean(routerIP), DECIMAL_PLACES)
            standardDeviation = round(statistics.stdev(routerIP), DECIMAL_PLACES)

        print("The avg RTT between {} and {} is: {} ms... The stdDev is: {} ms ".format(sourceNode, pairX[1], mean, standardDeviation))
    for pairX in ultimateDestinationIP:
        routerIP = []
        for el2 in pairX[2]:
            rttResult = el2[1].timestamp - el2[0].timestamp
            routerIP.append(rttResult)
        if len(routerIP) > 1:
            mean = round(statistics.mean(routerIP), DECIMAL_PLACES)
            standardDeviation = round(statistics.stdev(routerIP), DECIMAL_PLACES)

        print("The avg RTT between {} and {} is: {} ms... The stdDev is: {} ms ".format(sourceNode, pairX[1], mean, standardDeviation))



if __name__=='__main__':
    main()