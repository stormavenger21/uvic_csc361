
from ip import IP_Header
from udp import UDP_header
import struct
#this assignment uses code excerpts from packet_struct.py, which was provided in assignment 2

ICMP_H_Size=8

def icmpProcessHelper(inFile, lengthToRead):
    startPacket=inFile[0:lengthToRead]
    inFile=inFile[lengthToRead:]
    return startPacket,inFile

class ICMP_Header:
    version=None
    IHL=None
    TOS=None
    totalLen=None
    Identification=None
    encapsulatedProtocol=None
    checksum=None
    type=None
    code=None
    payload=None
    
    
    def __init__(self):
        self.version=None
        self.IHL=None
        self.TOS=None
        self.totalLen=None
        self.Identification=None
        self.encapsulatedProtocol={}
        self.checksum=None
        self.type=None
        self.code=None
        self.payload=None

    def findCode(self, buffer):
        self.code=struct.unpack("!B",buffer)[0]

    def findType(self, buffer):
        self.type=struct.unpack("!B",buffer)[0]

    def icmpData(self, binary):
        header, binary=icmpProcessHelper(binary,ICMP_H_Size)
        self.findType(header[0:1])
        self.findCode(header[1:2])
        self.payload=header[4:8]
        if self.type in [3,11]:
            ip_head=IP_Header()
            binary = ip_head.getIPinfo(binary)
            self.encapsulatedProtocol["IP4"]=ip_head
            if ip_head.Protocol==17:
                udp_head=UDP_header()
                binary=udp_head.populateFields(binary)
                self.encapsulatedProtocol["UDP"]=udp_head
        return binary

    def __str__(self):
        return str(self.__class__)+": "+str(self.__dict__)



