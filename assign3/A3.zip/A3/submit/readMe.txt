##CSC 361: A3 Analysis of IP Protocol


#Requirements:
R1: completed in main.py (coding)
R2: completed manually (no-coding). Please see requirement2.pdf

##required files. Must all be in same directory:
globalHeader.py
icmp.py
ip.py
main.py
packet.py
tcp.py
udp.py
<name of file>.cap

## Running tcp.py
1. Install Python 3.8.10 or higher
2. Open Terminal on UNIX-based OS, or powershell on Windows machine
3. Navigate to the directory containing main.py AND packet_struct.py AND the .cap file
4. Execute the following command in Terminal:

    python3 main.py <cap file name>
	

#Examples:
python3 main.py group1-trace1.pcap
python3 main.py group1-trace4.pcap >> results.txt

