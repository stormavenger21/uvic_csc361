import struct
#this assignment uses code excerpts from packet_struct.py, which was provided in assignment 2


def udpProcessHelper(inFile, lengthToRead):
        startPacket=inFile[0:lengthToRead]
        inFile=inFile[lengthToRead:]
        return startPacket,inFile

class UDP_header:


    sourcePort=None
    destinationPort=None
    length=None
    checksum=None


    def __init__(self):
        self.sourcePort=None
        self.destinationPort=None
        self.length=None
        self.checksum=None


    def sP(self, buffer):
        self.sourcePort=struct.unpack("!H",buffer)[0]


    def dP(self,buffer):
        self.destinationPort=struct.unpack("!H",buffer)[0]


    def len(self,buffer):
        self.length=struct.unpack("!H",buffer)[0]
    

    def checkS(self,buffer):
        self.checksum=struct.unpack("!H",buffer)[0]
    

    def populateFields(self,remainingPackets):
        headerSize=8
        header,remainingPackets=udpProcessHelper(remainingPackets,headerSize)
        self.sP(header[0:2])
        self.dP(header[2:4])
        self.len(header[4:6])
        self.checkS(header[6:8])
        return remainingPackets

    
    
    def __str__(self):
        result=str(self.__class__)+": "+str(self.__dict__)
        return result
    
    