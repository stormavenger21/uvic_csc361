import struct

#this assignment uses code excerpts from packet_struct.py, which was provided in assignment 2

IDENTICAL_D4A1 = 0xD4C3B2A1
IDENTICAL_4DA1 = 0x4D3CB2A1
IDENTICAL_d4 = 0xA1B2C3D4
IDENTICAL_4d = 0xA1B23C4D
'''
The writing application writes 0xa1b2c3d4 with it's native byte ordering 
format into this field. The reading application will read either 0xa1b2c3d4 (identical) 
or 0xd4c3b2a1 (swapped). If the reading application reads the swapped 0xd4c3b2a1 value, 
it knows that all the following fields will have to be swapped too. -instructor
'''
class globalHeader:
    microSec=None
    magicNumber=0 
    versionMajor=0 
    versionMinor=0 
    thisZone=0 
    sigFigs=0 
    snapLen=0 
    network=0 
    endian=None

    def __init__(self):
        self.microSec=None
        self.magicNumber=0
        self.versionMajor=0
        self.versionMinor=0
        self.thisZone=0
        self.sigFigs=0
        self.snapLen-0
        self.network=0
        self.endian=None

    def get_Global_H(self, capFile):
        self.magic_number = struct.unpack("<I", capFile[0:4])[0]
        #print(self.magic_number)
        if self.magic_number==IDENTICAL_D4A1:
            self.endian=">"
            self.microSec=True
        elif self.magic_number==IDENTICAL_d4:
            self.endian="<"
            self.microSec=True
        elif self.magic_number==IDENTICAL_4DA1:
            self.endian=">"
            self.microSec=False
        elif self.magic_number==IDENTICAL_4d:
            self.endian="<"
            self.microSec=False
        else:
            self.endian="<"
            print("error")


        count2=0
        self.version_major=struct.unpack(self.endian+"H",capFile[4:6])[0]
        self.version_minor=struct.unpack(self.endian+"H",capFile[6:8])[0]
        self.thiszone=struct.unpack(self.endian+"i",capFile[8:12])[0]
        self.sigfigs=struct.unpack(self.endian+"I",capFile[12:16])[0]
        self.snaplen=struct.unpack(self.endian+"I",capFile[16:20])[0]
        self.network=struct.unpack(self.endian+"I",capFile[20:])[0]
        count2+=1
        #print(count2)

    def __str__(self):
        return str(self.__class__)+": "+str(self.__dict__)