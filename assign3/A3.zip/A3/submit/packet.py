import struct
from udp import UDP_header
from ip import IP_Header
from icmp import ICMP_Header

from tcp import TCP_Header

#this assignment uses code excerpts from packet_struct.py, which was provided in assignment 2

ETHERNET_H_SZ=14
GLOBAL_H_SZ=24
PACKET_H_SZ=16

class Packet:
    #pcap_hd_info = None
    IP_header = None
    TCP_header = None
    timestamp = 0
    packet_No = 0
    RTT_value = 0
    RTT_flag = False
    buffer = None
    orig_time=0
    incl_len=0
    endian=None
    protocol=None
    protocol_type=None
    fragmented=None
    last_frag_offset=None
    
    
    
    def __init__(self):
        self.IP_header = IP_Header()
        self.TCP_header = TCP_Header()
        self.timestamp = 0
        self.packet_No =0
        self.RTT_value = 0.0
        self.RTT_flag = False
        self.buffer = None
        self.orig_time=0
        self.incl_len=0
        self.endian=None
        self.protocol=None
        self.protocol_type=None
        self.fragmented=None
        self.last_frag_offset=None

    def getIPandTCPheader(self):
        return ([self.IP_header.src_ip, self.TCP_header.src_port],[self.IP_header.dst_ip, self.TCP_header.dst_port],)

    def __str__(self):
        return str(self.__class__)+": "+str(self.__dict__)
    
    def getInclLen(self,binData,endianess,microseconds):
        #self.endian=endianess
        ts_sec=binData[0:4]
        ts_usec=binData[4:8]
        incl_len=struct.unpack(endianess+"I",binData[8:12])[0]
        self.timestamp_set(ts_sec,ts_usec,self.orig_time,microseconds)
        #if(numPackets):
        #    self.packet_No_set(numPackets)
        self.packet_No_set()
        self.incl_len=incl_len
        return incl_len
    

    def packetData(self, binary):
        dataChunk = binary[ETHERNET_H_SZ:]
        binary = self.IP_header.getIPinfo(dataChunk)
        count=0
        if binary != dataChunk:
            if self.IP_header.Protocol == 1:
                self.protocol = ICMP_Header()
                if self.IP_header.Flags["mf"]:
                    self.fragmented = True
                    self.protocol_type = "ICMP"
                    count+=1
                else:
                    binary = self.protocol.icmpData(binary)
                    self.last_frag_offset = self.IP_header.fragment_offset
                    if self.protocol.type in [0, 3, 3, 5, 8, 10, 11, 12, 13, 14]:
                        self.protocol_type = "ICMP"
                    else:
                        self.protocol_type = None
                    count-=1

            elif self.IP_header.Protocol == 17:
                self.protocol = UDP_header()
                if self.IP_header.Flags["mf"]:
                    self.fragmented = True
                    self.protocol_type = "UDP"
                else:
                    binary = self.protocol.populateFields(binary)
                    if (self.protocol.destinationPort <= 33625) and (self.protocol.destinationPort >= 33434):
                        self.protocol_type = "UDP"
                        self.last_frag_offset = self.IP_header.FragOffset
                    else:
                        self.protocol_type = None
            elif self.IP_header.Protocol == 6:
                self.protocol = TCP_Header()
                binary = self.protocol.getTCPinfo(binary)
                self.protocol_type = "IP"
        else:
            self.IP_header = None

    def packet_No_set(self):
        #self.packet_No = number
        #print(self.packet_No)
        Packet.packet_No += 1
        self.packet_No = Packet.packet_No
        if self.packet_No == 1:
            Packet.orig_time = self.timestamp
            self.orig_time = self.timestamp
            self.timestamp = 0

    def timestamp_set(self,buffer1,buffer2,orig_time,uSecInput):
        seconds=struct.unpack('I',buffer1)[0]
        if uSecInput:
            nanoseconds=0
            microseconds=struct.unpack('<I',buffer2)[0]
        else:
            microseconds=0
            nanoseconds=struct.unpack('<I',buffer2)[0]
        self.timestamp=round(seconds+microseconds*0.000001-orig_time,6)
        self.timestamp=round((seconds + (microseconds * 0.000001) + (nanoseconds * 0.000000001))-orig_time,6)
    
    
        
    def get_RTT_value(self,p):
        rtt = p.timestamp-self.timestamp
        self.RTT_value = round(rtt,8)

    def getflags(self):
        return self.TCP_header.flags

    
    def getLen(self):
        result=0
        hSize = self.IP_header.ip_header_len+self.TCP_header.data_offset
        len=self.IP_header.total_len
        result=len-hSize
        return result